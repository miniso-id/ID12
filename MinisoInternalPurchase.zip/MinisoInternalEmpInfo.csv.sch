<?xml version="1.0" encoding="utf-8"?>
<table name="MinisoInternalEmpInfo">
  <column no="1" label="EMPCODE" type="12" typeName="varchar" precision="0" scale="0" displaySize="20" />
  <column no="2" label="NAME" type="12" typeName="varchar" precision="0" scale="0" displaySize="50" />
  <column no="3" label="EMPLOYEETYPE" type="12" typeName="varchar" precision="0" scale="0" displaySize="15" />
</table>
