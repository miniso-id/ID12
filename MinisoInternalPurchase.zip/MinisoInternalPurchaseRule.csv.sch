<?xml version="1.0" encoding="utf-8"?>
<table name="MinisoInternalPurchaseRule">
  <column no="1" label="EMPLOYEETYPE" type="12" typeName="varchar" precision="0" scale="0" displaySize="15" />
  <column no="2" label="MONTHLIMITCOUNT" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
  <column no="3" label="ORDERAMOUNTLIMIT" type="2" typeName="numeric" precision="24" scale="4" displaySize="0" />
  <column no="4" label="DISCOUNT" type="2" typeName="numeric" precision="24" scale="4" displaySize="0" />
</table>
