<?xml version="1.0" encoding="utf-8"?>
<table name="DaInvChgReason">
  <column no="1" label="CODE" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="10" />
  <column no="2" label="ENGDESC" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="3" label="CHNDESC" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="4" label="LMODDATE" type="93" typeName="TIMESTAMP" precision="0" scale="0" displaySize="0" />
  <column no="5" label="LMODOPID" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="30" />
  <column no="6" label="USEINSTORE" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="7" label="REASONCLS" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
</table>
