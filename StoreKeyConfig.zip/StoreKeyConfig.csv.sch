<?xml version="1.0" encoding="utf-8"?>
<table name="StoreKeyConfig">
  <column no="1" label="CKEY" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="60" />
  <column no="2" label="CVALUE" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="2000" />
  <column no="3" label="BUSTYPE" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="4" label="ENTITYID" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="60" />
</table>
