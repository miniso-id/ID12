<?xml version="1.0" encoding="utf-8"?>
<table name="SaleOperRule">
  <column no="1" label="uuid" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="38" />
  <column no="2" label="OperType" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="64" />
  <column no="3" label="LmtTimes" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="4" label="LmtTotal" type="2" typeName="NUMERIC" precision="24" scale="2" displaySize="0" />
</table>
