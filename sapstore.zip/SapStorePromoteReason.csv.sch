<?xml version="1.0" encoding="utf-8"?>
<table name="SapStorePromoteReason">
  <column no="1" label="code" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="2" label="name" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="120" />
  <column no="3" label="prmReasonType" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="32" />
</table>
