<?xml version="1.0" encoding="utf-8"?>
<table name="SapInvModHighValueSort">
  <column no="1" label="sortCode" type="12" typeName="varchar" precision="0" scale="0" displaySize="32" />
  <column no="2" label="highPriceLimit" type="2" typeName="numeric" precision="24" scale="4" displaySize="0" />
</table>
