<?xml version="1.0" encoding="utf-8"?>
<table name="SapInvAdjType">
  <column no="1" label="code" type="12" typeName="varchar" precision="0" scale="0" displaySize="32" />
  <column no="2" label="name" type="12" typeName="varchar" precision="0" scale="0" displaySize="64" />
  <column no="3" label="typeflag" type="12" typeName="varchar" precision="0" scale="0" displaySize="64" />
  <column no="4" label="qtyLimit" type="2" typeName="numeric" precision="24" scale="4" displaySize="0" />
</table>
