<?xml version="1.0" encoding="utf-8"?>
<table name="SapReportLossType">
  <column no="1" label="code" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="2" label="name" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="64" />
  <column no="3" label="typeflag" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
</table>
