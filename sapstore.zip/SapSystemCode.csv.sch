<?xml version="1.0" encoding="utf-8"?>
<table name="SapSystemCode">
  <column no="1" label="type" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="30" />
  <column no="2" label="code" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="30" />
  <column no="3" label="name" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="255" />
  <column no="4" label="LocalCode" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="30" />
</table>
