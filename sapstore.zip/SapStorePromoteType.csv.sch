<?xml version="1.0" encoding="utf-8"?>
<table name="SapStorePromoteType">
  <column no="1" label="code" type="12" typeName="varchar" precision="0" scale="0" displaySize="20" />
  <column no="2" label="name" type="12" typeName="varchar" precision="0" scale="0" displaySize="120" />
  <column no="3" label="prmtype" type="12" typeName="varchar" precision="0" scale="0" displaySize="32" />
</table>
