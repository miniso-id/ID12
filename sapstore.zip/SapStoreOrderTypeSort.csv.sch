<?xml version="1.0" encoding="utf-8"?>
<table name="SapStoreOrderTypeSort">
  <column no="1" label="code" type="12" typeName="varchar" precision="0" scale="0" displaySize="20" />
  <column no="2" label="sortType" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
  <column no="3" label="sortCode" type="12" typeName="varchar" precision="0" scale="0" displaySize="20" />
</table>
