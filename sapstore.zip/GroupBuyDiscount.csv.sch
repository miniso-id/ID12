<?xml version="1.0" encoding="utf-8"?>
<table name="GroupBuyDiscount">
  <column no="1" label="uuid" type="12" typeName="varchar" precision="0" scale="0" displaySize="38" />
  <column no="2" label="discountType" type="12" typeName="varchar" precision="0" scale="0" displaySize="10" />
  <column no="3" label="levelValue" type="2" typeName="numeric" precision="20" scale="4" displaySize="0" />
  <column no="4" label="discount" type="2" typeName="numeric" precision="20" scale="4" displaySize="0" />
  <column no="5" label="biztype" type="12" typeName="varchar" precision="0" scale="0" displaySize="4" />
</table>
