<?xml version="1.0" encoding="utf-8"?>
<table name="SapStoreOrderType">
  <column no="1" label="uuid" type="12" typeName="varchar" precision="0" scale="0" displaySize="38" />
  <column no="2" label="code" type="12" typeName="varchar" precision="0" scale="0" displaySize="16" />
  <column no="3" label="name" type="12" typeName="varchar" precision="0" scale="0" displaySize="32" />
  <column no="4" label="includegdsortcode" type="12" typeName="varchar" precision="0" scale="0" displaySize="1024" />
  <column no="5" label="excludegdsortcode" type="12" typeName="varchar" precision="0" scale="0" displaySize="1024" />
  <column no="6" label="isnormal" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
  <column no="7" label="ISDANGEROUS" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
</table>
