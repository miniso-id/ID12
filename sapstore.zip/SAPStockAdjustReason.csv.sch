<?xml version="1.0" encoding="utf-8"?>
<table name="SAPStockAdjustReason">
  <column no="1" label="uuid" type="12" typeName="varchar" precision="0" scale="0" displaySize="38" />
  <column no="2" label="adjType" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
  <column no="3" label="code" type="12" typeName="varchar" precision="0" scale="0" displaySize="20" />
  <column no="4" label="name" type="12" typeName="varchar" precision="0" scale="0" displaySize="120" />
  <column no="5" label="GoodsFlag" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
  <column no="6" label="compensate" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
</table>
