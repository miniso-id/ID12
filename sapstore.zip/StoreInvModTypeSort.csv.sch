<?xml version="1.0" encoding="utf-8"?>
<table name="StoreInvModTypeSort">
  <column no="1" label="code" type="12" typeName="varchar" precision="0" scale="0" displaySize="32" />
  <column no="2" label="SortCode" type="12" typeName="varchar" precision="0" scale="0" displaySize="64" />
  <column no="3" label="Include" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
</table>
