<?xml version="1.0" encoding="utf-8"?>
<table name="SapStoreReturnOrderType">
  <column no="1" label="code" type="12" typeName="varchar" precision="0" scale="0" displaySize="16" />
  <column no="2" label="name" type="12" typeName="varchar" precision="0" scale="0" displaySize="120" />
  <column no="3" label="includegdsortcode" type="12" typeName="varchar" precision="0" scale="0" displaySize="1024" />
  <column no="4" label="excludegdsortcode" type="12" typeName="varchar" precision="0" scale="0" displaySize="1024" />
  <column no="5" label="goodsflag" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
</table>
