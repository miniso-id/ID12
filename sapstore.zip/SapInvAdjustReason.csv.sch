<?xml version="1.0" encoding="utf-8"?>
<table name="SapInvAdjustReason">
  <column no="1" label="uuid" type="12" typeName="varchar" precision="0" scale="0" displaySize="38" />
  <column no="2" label="code" type="12" typeName="varchar" precision="0" scale="0" displaySize="16" />
  <column no="3" label="name" type="12" typeName="varchar" precision="0" scale="0" displaySize="32" />
</table>
