<?xml version="1.0" encoding="utf-8"?>
<table name="SapInvAdjTypeReason">
  <column no="1" label="code" type="12" typeName="varchar" precision="0" scale="0" displaySize="32" />
  <column no="2" label="name" type="12" typeName="varchar" precision="0" scale="0" displaySize="64" />
  <column no="3" label="adjTypeCode" type="12" typeName="varchar" precision="0" scale="0" displaySize="20" />
  <column no="4" label="AdjFlag" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
</table>
