<?xml version="1.0" encoding="utf-8"?>
<table name="StoreSlot">
  <column no="1" label="shelfid" type="12" typeName="varchar" precision="0" scale="0" displaySize="30" />
  <column no="2" label="shelfdes" type="12" typeName="varchar" precision="0" scale="0" displaySize="255" />
  <column no="3" label="shelfins" type="12" typeName="varchar" precision="0" scale="0" displaySize="120" />
</table>
