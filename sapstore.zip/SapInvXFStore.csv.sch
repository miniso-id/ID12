<?xml version="1.0" encoding="utf-8"?>
<table name="SapInvXFStore">
  <column no="1" label="gid" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="2" label="code" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="10" />
  <column no="3" label="name" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="64" />
  <column no="4" label="katr3" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="10" />
  <column no="5" label="sapCode" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
</table>
