<?xml version="1.0" encoding="utf-8"?>
<table name="VASItem">
  <column no="1" label="CODE" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="32" />
  <column no="2" label="NAME" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="100" />
  <column no="3" label="VASSORT" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="32" />
  <column no="4" label="CPRICE" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
  <column no="5" label="STPRC" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
  <column no="6" label="RTLPRC" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
  <column no="7" label="NOTE" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="255" />
</table>
