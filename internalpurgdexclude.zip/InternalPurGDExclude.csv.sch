<?xml version="1.0" encoding="utf-8"?>
<table name="InternalPurGDExclude">
  <column no="1" label="GID" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
  <column no="2" label="ISEXCLUDE" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
</table>
