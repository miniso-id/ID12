<?xml version="1.0" encoding="utf-8"?>
<table name="PomWholeSaleItem.csv">
  <column no="1" label="UUID" type="12" typeName="VARCHAR2" precision="38" scale="0" displaySize="38" />
  <column no="2" label="ITEMGROUPUUID" type="12" typeName="VARCHAR2" precision="255" scale="0" displaySize="255" />
  <column no="3" label="EXECSEQNUMBER" type="2" typeName="NUMBER" precision="10" scale="0" displaySize="11" />
  <column no="4" label="BILLNUMBER" type="12" typeName="VARCHAR2" precision="20" scale="0" displaySize="20" />
  <column no="5" label="AUDITTIME" type="93" typeName="DATE" precision="0" scale="0" displaySize="7" />
  <column no="6" label="FSTART" type="93" typeName="DATE" precision="0" scale="0" displaySize="7" />
  <column no="7" label="FFINISH" type="93" typeName="DATE" precision="0" scale="0" displaySize="7" />
  <column no="8" label="CONFLICTGROUP" type="12" typeName="VARCHAR2" precision="32" scale="0" displaySize="32" />
  <column no="9" label="REMARK" type="12" typeName="VARCHAR2" precision="1024" scale="0" displaySize="1024" />
  <column no="10" label="DOCUMENT" type="2005" typeName="CLOB" precision="0" scale="0" displaySize="4000" />
  <column no="11" label="LIMITTYPE" type="12" typeName="VARCHAR2" precision="20" scale="0" displaySize="20" />
  <column no="12" label="LIMITMODE" type="12" typeName="VARCHAR2" precision="20" scale="0" displaySize="20" />
  <column no="13" label="LIMITQUANTITY" type="2" typeName="NUMBER" precision="19" scale="3" displaySize="21" />
  <column no="14" label="LIMITTYPE2" type="12" typeName="VARCHAR2" precision="20" scale="0" displaySize="20" />
  <column no="15" label="LIMITMODE2" type="12" typeName="VARCHAR2" precision="20" scale="0" displaySize="20" />
  <column no="16" label="LIMITQUANTITY2" type="2" typeName="NUMBER" precision="19" scale="3" displaySize="21" />
</table>
