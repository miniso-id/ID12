<?xml version="1.0" encoding="utf-8"?>
<table name="PomSingleForm.csv">
  <column no="1" label="UUID" type="12" typeName="VARCHAR2" precision="38" scale="0" displaySize="38" />
  <column no="2" label="TYPE" type="12" typeName="VARCHAR2" precision="20" scale="0" displaySize="20" />
  <column no="3" label="ENTITYUUID" type="12" typeName="VARCHAR2" precision="60" scale="0" displaySize="60" />
  <column no="4" label="ENTITYCODE" type="12" typeName="VARCHAR2" precision="20" scale="0" displaySize="20" />
  <column no="5" label="QPC" type="2" typeName="NUMBER" precision="22" scale="6" displaySize="24" />
  <column no="6" label="STEPTYPE" type="12" typeName="VARCHAR2" precision="20" scale="0" displaySize="20" />
  <column no="7" label="STEPOPERATOR" type="12" typeName="VARCHAR2" precision="20" scale="0" displaySize="20" />
  <column no="8" label="STEPVALUE" type="2" typeName="NUMBER" precision="19" scale="3" displaySize="21" />
  <column no="9" label="FORM" type="12" typeName="VARCHAR2" precision="20" scale="0" displaySize="20" />
  <column no="10" label="PROMVALUE" type="2" typeName="NUMBER" precision="19" scale="4" displaySize="21" />
  <column no="11" label="ITEMUUID" type="12" typeName="VARCHAR2" precision="38" scale="0" displaySize="38" />
  <column no="12" label="FSTART" type="93" typeName="DATE" precision="0" scale="0" displaySize="7" />
  <column no="13" label="FFINISH" type="93" typeName="DATE" precision="0" scale="0" displaySize="7" />
</table>
