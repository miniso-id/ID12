<?xml version="1.0" encoding="utf-8"?>
<table name="PomItemGroup.csv">
  <column no="1" label="TYPE" type="12" typeName="VARCHAR2" precision="20" scale="0" displaySize="20" />
  <column no="2" label="GROUPNUMBER" type="12" typeName="VARCHAR2" precision="100" scale="0" displaySize="100" />
  <column no="3" label="EXECSEQORDER" type="12" typeName="VARCHAR2" precision="20" scale="0" displaySize="20" />
  <column no="4" label="INPOLICY" type="12" typeName="VARCHAR2" precision="40" scale="0" displaySize="40" />
  <column no="5" label="OUTPOLICY" type="12" typeName="VARCHAR2" precision="100" scale="0" displaySize="100" />
  <column no="6" label="GIFTCONDITION" type="2" typeName="NUMBER" precision="1" scale="0" displaySize="2" />
</table>
