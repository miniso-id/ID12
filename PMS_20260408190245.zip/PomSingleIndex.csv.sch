<?xml version="1.0" encoding="utf-8"?>
<table name="PomSingleIndex.csv">
  <column no="1" label="ITEMUUID" type="12" typeName="VARCHAR2" precision="38" scale="0" displaySize="38" />
  <column no="2" label="ITEMGROUPUUID" type="12" typeName="VARCHAR2" precision="255" scale="0" displaySize="255" />
  <column no="3" label="FSTART" type="93" typeName="DATE" precision="0" scale="0" displaySize="7" />
  <column no="4" label="FFINISH" type="93" typeName="DATE" precision="0" scale="0" displaySize="7" />
  <column no="5" label="PRODUCTCONDDOC" type="2005" typeName="CLOB" precision="0" scale="0" displaySize="4000" />
  <column no="6" label="PRODUCTEXPRESSION" type="2005" typeName="CLOB" precision="0" scale="0" displaySize="4000" />
  <column no="7" label="PRODUCTUUID" type="12" typeName="VARCHAR2" precision="38" scale="0" displaySize="38" />
  <column no="8" label="QPC" type="2" typeName="NUMBER" precision="22" scale="6" displaySize="24" />
</table>
