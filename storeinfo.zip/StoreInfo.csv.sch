<?xml version="1.0" encoding="utf-8"?>
<table name="StoreInfo">
  <column no="1" label="Name" type="12" typeName="varchar" precision="0" scale="0" displaySize="255" />
  <column no="2" label="Value" type="12" typeName="varchar" precision="0" scale="0" displaySize="255" />
</table>
