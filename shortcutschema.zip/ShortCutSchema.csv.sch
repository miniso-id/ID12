<?xml version="1.0" encoding="utf-8"?>
<table name="ShortCutSchema">
  <column no="1" label="GID" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="2" label="CODE" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="32" />
  <column no="3" label="NAME" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="128" />
</table>
