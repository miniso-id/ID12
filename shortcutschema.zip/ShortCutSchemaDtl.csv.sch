<?xml version="1.0" encoding="utf-8"?>
<table name="ShortCutSchemaDtl">
  <column no="1" label="SCMCODE" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="32" />
  <column no="2" label="GDGID" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
</table>
