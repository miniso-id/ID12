<?xml version="1.0" encoding="utf-8"?>
<table name="Store">
  <column no="1" label="Gid" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
  <column no="2" label="Code" type="12" typeName="varchar" precision="0" scale="0" displaySize="10" />
  <column no="3" label="Name" type="12" typeName="varchar" precision="0" scale="0" displaySize="64" />
  <column no="4" label="SUSPENDBGNDATE" type="93" typeName="timestamp" precision="0" scale="0" displaySize="0" />
  <column no="5" label="SUSPENDENDDATE" type="93" typeName="timestamp" precision="0" scale="0" displaySize="0" />
  <column no="6" label="address" type="12" typeName="varchar" precision="0" scale="0" displaySize="255" />
  <column no="7" label="phone" type="12" typeName="varchar" precision="0" scale="0" displaySize="40" />
  <column no="8" label="OrgGid" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
</table>
