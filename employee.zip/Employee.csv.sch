<?xml version="1.0" encoding="utf-8"?>
<table name="Employee">
  <column no="1" label="gid" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
  <column no="2" label="code" type="12" typeName="varchar" precision="0" scale="0" displaySize="10" />
  <column no="3" label="name" type="12" typeName="varchar" precision="0" scale="0" displaySize="100" />
  <column no="4" label="PassWD" type="12" typeName="varchar" precision="0" scale="0" displaySize="32" />
  <column no="5" label="Lwprc" type="12" typeName="varchar" precision="0" scale="0" displaySize="30" />
  <column no="6" label="WorkType" type="12" typeName="varchar" precision="0" scale="0" displaySize="100" />
  <column no="7" label="MaxBckTotal" type="2" typeName="numeric" precision="20" scale="2" displaySize="0" />
  <column no="8" label="MNEMONICCODE" type="12" typeName="varchar" precision="0" scale="0" displaySize="50" />
  <column no="9" label="PROPERTY" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
  <column no="10" label="PwdSetDate" type="93" typeName="timestamp" precision="0" scale="0" displaySize="0" />
</table>
