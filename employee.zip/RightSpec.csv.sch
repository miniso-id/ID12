<?xml version="1.0" encoding="utf-8"?>
<table name="RightSpec">
  <column no="1" label="gid" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
  <column no="2" label="name" type="12" typeName="varchar" precision="0" scale="0" displaySize="100" />
</table>
