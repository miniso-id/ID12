<?xml version="1.0" encoding="utf-8"?>
<table name="EmpRight">
  <column no="1" label="EmpGid" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="2" label="RightGid" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
</table>
