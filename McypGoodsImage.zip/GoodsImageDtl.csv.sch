<?xml version="1.0" encoding="utf-8"?>
<table name="GoodsImageDtl">
  <column no="1" label="UUID" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="38" />
  <column no="2" label="OWNERUUID" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="38" />
  <column no="3" label="ZPICNAME" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="40" />
  <column no="4" label="ZPICURL" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="1000" />
  <column no="5" label="ZMPICTURE" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="4" />
</table>
