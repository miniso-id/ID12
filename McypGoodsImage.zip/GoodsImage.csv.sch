<?xml version="1.0" encoding="utf-8"?>
<table name="GoodsImage">
  <column no="1" label="UUID" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="38" />
  <column no="2" label="GID" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
</table>
