<?xml version="1.0" encoding="utf-8"?>
<table name="PscpDtl">
  <column no="1" label="CODE" type="12" typeName="VARCHAR2" precision="20" scale="0" displaySize="20" />
  <column no="2" label="CLS" type="12" typeName="VARCHAR2" precision="16" scale="0" displaySize="16" />
  <column no="3" label="ISRAW" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="4" label="LINE" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="5" label="GDGID" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="6" label="QTY" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
  <column no="7" label="QPC" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
  <column no="8" label="MUNIT" type="12" typeName="VARCHAR2" precision="6" scale="0" displaySize="6" />
  <column no="9" label="GDNAME" type="12" typeName="VARCHAR2" precision="80" scale="0" displaySize="80" />
  <column no="10" label="MAINGDGID" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
</table>
