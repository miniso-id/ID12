<?xml version="1.0" encoding="utf-8"?>
<table name="GdPrcList">
  <column no="1" label="StoreGid" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="2" label="GDGID" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="3" label="GDCODE" type="12" typeName="VARCHAR2" precision="20" scale="0" displaySize="20" />
  <column no="4" label="QPCSTR" type="12" typeName="VARCHAR2" precision="15" scale="0" displaySize="15" />
  <column no="5" label="QPC" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
  <column no="6" label="MUNIT" type="12" typeName="VARCHAR2" precision="15" scale="0" displaySize="15" />
  <column no="7" label="PRICE1" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
  <column no="8" label="PRICE2" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
  <column no="9" label="PRICE3" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
  <column no="10" label="PRICE4" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
  <column no="11" label="PRICE5" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
</table>
