<?xml version="1.0" encoding="utf-8"?>
<table name="PriceF2">
  <column no="1" label="GDGID" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="2" label="GDCODE" type="12" typeName="VARCHAR2" precision="20" scale="0" displaySize="20" />
  <column no="3" label="BILLNUM" type="12" typeName="VARCHAR2" precision="14" scale="0" displaySize="14" />
  <column no="4" label="BILLLINE" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
</table>
