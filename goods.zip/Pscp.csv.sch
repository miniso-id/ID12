<?xml version="1.0" encoding="utf-8"?>
<table name="Pscp">
  <column no="1" label="CODE" type="12" typeName="VARCHAR2" precision="20" scale="0" displaySize="20" />
  <column no="2" label="NAME" type="12" typeName="VARCHAR2" precision="50" scale="0" displaySize="50" />
  <column no="3" label="CLS" type="12" typeName="VARCHAR2" precision="16" scale="0" displaySize="16" />
  <column no="4" label="LSTUPDTIME" type="93" typeName="DATE" precision="0" scale="0" displaySize="7" />
  <column no="5" label="GDGID" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
</table>
