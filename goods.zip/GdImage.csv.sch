<?xml version="1.0" encoding="utf-8"?>
<table name="GdImage">
  <column no="1" label="Gid" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="2" label="ImageID" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="255" />
  <column no="3" label="ExtUrl" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="1000" />
</table>
