<?xml version="1.0" encoding="utf-8"?>
<table name="PromoteQty">
  <column no="1" label="CLS" type="12" typeName="VARCHAR2" precision="16" scale="0" displaySize="16" />
  <column no="2" label="BILLNUM" type="12" typeName="VARCHAR2" precision="14" scale="0" displaySize="14" />
  <column no="3" label="PRMNO" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="4" label="QTY" type="2" typeName="NUMBER" precision="24" scale="2" displaySize="26" />
  <column no="5" label="PRMRATE" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
  <column no="6" label="PRMTOTAL" type="2" typeName="NUMBER" precision="24" scale="2" displaySize="26" />
  <column no="7" label="IFGFT" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="8" label="GFTQTY" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
</table>
