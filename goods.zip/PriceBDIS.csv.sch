<?xml version="1.0" encoding="utf-8"?>
<table name="PriceBDIS">
  <column no="1" label="BILLNUM" type="12" typeName="VARCHAR2" precision="14" scale="0" displaySize="14" />
  <column no="2" label="QTY" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
  <column no="3" label="RTLPRC" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
  <column no="4" label="PRMNO" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="5" label="GFTQTY" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
</table>
