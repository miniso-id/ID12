<?xml version="1.0" encoding="utf-8"?>
<table name="PromoteAC">
  <column no="1" label="NUM" type="12" typeName="VARCHAR2" precision="14" scale="0" displaySize="14" />
  <column no="2" label="CLS" type="12" typeName="VARCHAR2" precision="16" scale="0" displaySize="16" />
  <column no="3" label="ACTIVITYCODE" type="12" typeName="VARCHAR2" precision="20" scale="0" displaySize="20" />
</table>
