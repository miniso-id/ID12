<?xml version="1.0" encoding="utf-8"?>
<table name="PromoteGft">
  <column no="1" label="StoreGid" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="2" label="Cls" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="10" />
  <column no="3" label="BillNum" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="14" />
  <column no="4" label="PrmNo" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="5" label="Flag" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="6" label="BillLine" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="7" label="GftGid" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="8" label="GftCode" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="9" label="QTY" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
  <column no="10" label="GFTQPC" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
  <column no="11" label="PROMPRC" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
  <column no="12" label="PROMMBRPRC" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
  <column no="13" label="UsePromMbrPrc" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
</table>
