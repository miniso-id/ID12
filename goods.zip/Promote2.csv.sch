<?xml version="1.0" encoding="utf-8"?>
<table name="Promote2">
  <column no="1" label="BILLCLS" type="12" typeName="VARCHAR2" precision="16" scale="0" displaySize="16" />
  <column no="2" label="BILLNUM" type="12" typeName="VARCHAR2" precision="14" scale="0" displaySize="14" />
  <column no="3" label="CYLNO" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="4" label="SGRPNO" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="5" label="GDGID" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="6" label="GDINPUT" type="12" typeName="VARCHAR2" precision="20" scale="0" displaySize="20" />
  <column no="7" label="CFGSTR" type="12" typeName="VARCHAR2" precision="32" scale="0" displaySize="32" />
  <column no="8" label="ASTART" type="93" typeName="DATE" precision="0" scale="0" displaySize="7" />
  <column no="9" label="AFINISH" type="93" typeName="DATE" precision="0" scale="0" displaySize="7" />
  <column no="10" label="CYCLE" type="93" typeName="DATE" precision="0" scale="0" displaySize="7" />
  <column no="11" label="CSTART" type="93" typeName="DATE" precision="0" scale="0" displaySize="7" />
  <column no="12" label="CFINISH" type="93" typeName="DATE" precision="0" scale="0" displaySize="7" />
  <column no="13" label="QTY" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
  <column no="14" label="RATIO" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
</table>
