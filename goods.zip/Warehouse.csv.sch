<?xml version="1.0" encoding="utf-8"?>
<table name="Warehouse">
  <column no="1" label="STOREGID" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="2" label="GID" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="3" label="CODE" type="12" typeName="VARCHAR2" precision="10" scale="0" displaySize="10" />
  <column no="4" label="NAME" type="12" typeName="VARCHAR2" precision="50" scale="0" displaySize="50" />
  <column no="5" label="ISHEADQUARTERWRH" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="6" label="INPGBUS" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
</table>
