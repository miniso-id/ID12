<?xml version="1.0" encoding="utf-8"?>
<table name="MbrPromoteBill">
  <column no="1" label="BILLNUM" type="12" typeName="VARCHAR2" precision="14" scale="0" displaySize="14" />
  <column no="2" label="BILLCLS" type="12" typeName="VARCHAR2" precision="16" scale="0" displaySize="16" />
  <column no="3" label="ASTART" type="93" typeName="DATE" precision="0" scale="0" displaySize="7" />
  <column no="4" label="AFINISH" type="93" typeName="DATE" precision="0" scale="0" displaySize="7" />
</table>
