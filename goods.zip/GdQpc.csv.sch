<?xml version="1.0" encoding="utf-8"?>
<table name="GdQpc">
  <column no="1" label="StoreGid" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="2" label="GID" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="3" label="QPCSTR" type="12" typeName="VARCHAR2" precision="20" scale="0" displaySize="20" />
  <column no="4" label="QPC" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
  <column no="5" label="ISDU" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="6" label="ISPU" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="7" label="ISWU" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="8" label="ISRU" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="9" label="QPCDESC" type="12" typeName="VARCHAR2" precision="60" scale="0" displaySize="60" />
</table>
