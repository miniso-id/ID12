<?xml version="1.0" encoding="utf-8"?>
<table name="GdInvoiceRule">
  <column no="1" label="UUID" type="12" typeName="VARCHAR2" precision="38" scale="0" displaySize="38" />
  <column no="2" label="INPUTTYPE" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="3" label="RULE" type="12" typeName="VARCHAR2" precision="255" scale="0" displaySize="255" />
  <column no="4" label="ERRINFO" type="12" typeName="VARCHAR2" precision="255" scale="0" displaySize="255" />
  <column no="5" label="PROMPTINFO" type="12" typeName="VARCHAR2" precision="255" scale="0" displaySize="255" />
</table>
