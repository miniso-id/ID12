<?xml version="1.0" encoding="utf-8"?>
<table name="SortsPrinterName">
  <column no="1" label="SORTCODES" type="12" typeName="VARCHAR2" precision="255" scale="0" displaySize="255" />
  <column no="2" label="PRINTERNAME" type="12" typeName="VARCHAR2" precision="255" scale="0" displaySize="255" />
  <column no="3" label="TYPE" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
</table>
