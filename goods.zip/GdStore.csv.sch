<?xml version="1.0" encoding="utf-8"?>
<table name="GdStore">
  <column no="1" label="GdGid" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="2" label="HighInv" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
  <column no="3" label="LowInv" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
  <column no="4" label="StdShow" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
  <column no="5" label="ALC" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="10" />
  <column no="6" label="HighOrd" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
  <column no="7" label="LowOrd" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
  <column no="8" label="BusGate" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="9" label="BusGateName" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="255" />
  <column no="10" label="ABCType" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="11" label="BckAlc" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
</table>
