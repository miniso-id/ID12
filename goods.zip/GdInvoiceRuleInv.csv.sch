<?xml version="1.0" encoding="utf-8"?>
<table name="GdInvoiceRuleInv">
  <column no="1" label="DATACAT" type="12" typeName="VARCHAR2" precision="32" scale="0" displaySize="32" />
  <column no="2" label="PROPERTYNAME" type="12" typeName="VARCHAR2" precision="20" scale="0" displaySize="20" />
  <column no="3" label="PROPERTYVALUE" type="12" typeName="VARCHAR2" precision="120" scale="0" displaySize="120" />
  <column no="4" label="UUID" type="12" typeName="VARCHAR2" precision="38" scale="0" displaySize="38" />
</table>
