<?xml version="1.0" encoding="utf-8"?>
<table name="Promote">
  <column no="1" label="StoreGid" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="2" label="Cls" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="10" />
  <column no="3" label="BillNum" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="14" />
  <column no="4" label="BillLine" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="5" label="Flag" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="6" label="GdGid" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="7" label="GdCode" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="8" label="ASTART" type="93" typeName="DATE" precision="0" scale="0" displaySize="7" />
  <column no="9" label="AFINISH" type="93" typeName="DATE" precision="0" scale="0" displaySize="7" />
  <column no="10" label="OCRTIME" type="93" typeName="DATE" precision="0" scale="0" displaySize="7" />
  <column no="11" label="PSETTLENO" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="12" label="CSTART" type="93" typeName="DATE" precision="0" scale="0" displaySize="7" />
  <column no="13" label="CFINISH" type="93" typeName="DATE" precision="0" scale="0" displaySize="7" />
  <column no="14" label="CYCLE" type="93" typeName="DATE" precision="0" scale="0" displaySize="7" />
  <column no="15" label="CSPEC" type="12" typeName="VARCHAR2" precision="255" scale="0" displaySize="255" />
  <column no="16" label="TOPICNAME" type="12" typeName="VARCHAR2" precision="20" scale="0" displaySize="20" />
  <column no="17" label="PRMTYPE" type="12" typeName="VARCHAR2" precision="20" scale="0" displaySize="20" />
  <column no="18" label="QPC" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
  <column no="19" label="QTY" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
  <column no="20" label="FIXRATIO" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
  <column no="21" label="GFTRATIO" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
  <column no="22" label="HASCOND" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="23" label="EXPROM" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="24" label="ISVERIFYTOAPPLY" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="25" label="ISAPPLYFORMEMBER" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="26" label="ISNOTACCUMULATEGFT" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="27" label="GROUPNO" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
</table>
