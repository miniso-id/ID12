<?xml version="1.0" encoding="utf-8"?>
<table name="SortGoods">
  <column no="1" label="StoreGid" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="2" label="ACODE" type="12" typeName="VARCHAR2" precision="13" scale="0" displaySize="13" />
  <column no="3" label="SCODE" type="12" typeName="VARCHAR2" precision="20" scale="0" displaySize="20" />
  <column no="4" label="GID" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="5" label="CATALOG" type="1" typeName="CHAR" precision="1" scale="0" displaySize="1" />
</table>
