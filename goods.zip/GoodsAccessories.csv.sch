<?xml version="1.0" encoding="utf-8"?>
<table name="GoodsAccessories">
  <column no="1" label="Uuid" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="38" />
  <column no="2" label="GDGid" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="3" label="accGid" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="4" label="GoodsRate" type="2" typeName="NUMERIC" precision="24" scale="4" displaySize="0" />
  <column no="5" label="AccessoryRate" type="2" typeName="NUMERIC" precision="24" scale="4" displaySize="0" />
  <column no="6" label="RoundType" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="16" />
</table>
