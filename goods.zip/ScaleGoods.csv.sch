<?xml version="1.0" encoding="utf-8"?>
<table name="ScaleGoods">
  <column no="1" label="GDGID" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="2" label="CODE" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="16" />
  <column no="3" label="SHORTCUT" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="16" />
  <column no="4" label="PRINTLABELCODE" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="5" label="CUSTOMFIELD1" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="6" label="CUSTOMFIELD2" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="7" label="CUSTOMFIELD3" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="8" label="CUSTOMFIELD4" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="9" label="CUSTOMFIELD5" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="10" label="CUSTOMFIELD6" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="1024" />
  <column no="11" label="CUSTOMFIELD7" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="12" label="CUSTOMFIELD8" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="13" label="CUSTOMFIELD9" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="14" label="CUSTOMFIELD10" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="15" label="CUSTOMFIELD11" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="16" label="CUSTOMFIELD12" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="17" label="CUSTOMFIELD13" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="18" label="CUSTOMFIELD14" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="19" label="CUSTOMFIELD15" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
</table>
