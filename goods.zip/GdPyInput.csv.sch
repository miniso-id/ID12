<?xml version="1.0" encoding="utf-8"?>
<table name="GdPyInput">
  <column no="1" label="StoreGid" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="2" label="GID" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="3" label="CODE" type="12" typeName="VARCHAR2" precision="80" scale="0" displaySize="80" />
</table>
