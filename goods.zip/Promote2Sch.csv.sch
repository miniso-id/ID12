<?xml version="1.0" encoding="utf-8"?>
<table name="Promote2Sch">
  <column no="1" label="BILLCLS" type="12" typeName="VARCHAR2" precision="16" scale="0" displaySize="16" />
  <column no="2" label="BILLNUM" type="12" typeName="VARCHAR2" precision="14" scale="0" displaySize="14" />
  <column no="3" label="CYLNO" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="4" label="LINE" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="5" label="CUSTSTYLE" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="6" label="QTYLO" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
  <column no="7" label="QTYHI" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
  <column no="8" label="AMTLO" type="2" typeName="NUMBER" precision="24" scale="2" displaySize="26" />
  <column no="9" label="AMTHI" type="2" typeName="NUMBER" precision="24" scale="2" displaySize="26" />
  <column no="10" label="PRICE" type="2" typeName="NUMBER" precision="24" scale="2" displaySize="26" />
  <column no="11" label="DISCOUNT" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
  <column no="12" label="DISAMT" type="2" typeName="NUMBER" precision="24" scale="2" displaySize="26" />
  <column no="13" label="PRMTAG" type="12" typeName="VARCHAR2" precision="16" scale="0" displaySize="16" />
  <column no="14" label="LMTQTY" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
</table>
