<?xml version="1.0" encoding="utf-8"?>
<table name="PriceFDIS">
  <column no="1" label="BILLNUM" type="12" typeName="VARCHAR2" precision="14" scale="0" displaySize="14" />
  <column no="2" label="QTY" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
  <column no="3" label="RTLPRC" type="2" typeName="NUMBER" precision="24" scale="4" displaySize="26" />
</table>
