<?xml version="1.0" encoding="utf-8"?>
<table name="LimitBusSort">
  <column no="1" label="SORTCODE" type="12" typeName="VARCHAR2" precision="20" scale="0" displaySize="20" />
  <column no="2" label="MINSALEQTY" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
</table>
