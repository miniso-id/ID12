<?xml version="1.0" encoding="utf-8"?>
<table name="ExpDatePromDtlInv">
  <column no="1" label="GDGID" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="2" label="BGNDATE" type="93" typeName="TIMESTAMP" precision="0" scale="0" displaySize="0" />
  <column no="3" label="ENDDATE" type="93" typeName="TIMESTAMP" precision="0" scale="0" displaySize="0" />
  <column no="4" label="TIMELIMIT" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="5" label="PRMTYPE" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="6" label="DISCOUNT" type="2" typeName="NUMERIC" precision="24" scale="4" displaySize="0" />
  <column no="7" label="PRICE" type="2" typeName="NUMERIC" precision="24" scale="4" displaySize="0" />
  <column no="8" label="SORT" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="13" />
  <column no="9" label="BEGINTIME" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="10" />
  <column no="10" label="ENDTIME" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="10" />
  <column no="11" label="LSTUPDTIME" type="93" typeName="TIMESTAMP" precision="0" scale="0" displaySize="0" />
  <column no="12" label="SRCNUM" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="14" />
</table>
