<?xml version="1.0" encoding="utf-8"?>
<table name="SaleGoodsProperty">
  <column no="1" label="PROPERTY" type="1" typeName="CHAR" precision="8" scale="0" displaySize="8" />
</table>
