<?xml version="1.0" encoding="utf-8"?>
<table name="CustomCodeConfig">
  <column no="1" label="StoreGid" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="2" label="TOTALLEN" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="3" label="FLAG" type="12" typeName="VARCHAR2" precision="2" scale="0" displaySize="2" />
  <column no="4" label="CodeLen" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="5" label="QtyLen" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="6" label="AmtLen" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="7" label="PrcLen" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="8" label="ExpDateLen" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="9" label="CHKLEN" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
  <column no="10" label="CODETYPE" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="39" />
</table>
