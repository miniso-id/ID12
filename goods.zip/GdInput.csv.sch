<?xml version="1.0" encoding="utf-8"?>
<table name="GdInput">
  <column no="1" label="StoreGid" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="2" label="Gid" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="3" label="Code" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="32" />
  <column no="4" label="CodeType" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="5" label="RtlPRC" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
  <column no="6" label="QPC" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
  <column no="7" label="QPCSTR" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="15" />
  <column no="8" label="Munit" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="6" />
  <column no="9" label="MBRPRC" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
  <column no="10" label="LWTRtlPRC" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
  <column no="11" label="Score" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="12" label="Catalog" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="1" />
  <column no="13" label="IMPPRC" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
  <column no="14" label="StdRtlPrc" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
  <column no="15" label="StdMbrPrc" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
  <column no="16" label="highRtlPrc" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
  <column no="17" label="adjTime" type="93" typeName="TIMESTAMP" precision="0" scale="0" displaySize="0" />
  <column no="18" label="tokenPrc" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
  <column no="19" label="realBarCode" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="20" label="giRtlPrc" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
  <column no="21" label="pricing" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="22" label="field1" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
  <column no="23" label="field2" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
</table>
