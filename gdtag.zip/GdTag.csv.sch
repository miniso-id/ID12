<?xml version="1.0" encoding="utf-8"?>
<table name="GdTag">
  <column no="1" label="GdGid" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
  <column no="2" label="Tag" type="12" typeName="varchar" precision="0" scale="0" displaySize="20" />
  <column no="3" label="OrgGid" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
</table>
