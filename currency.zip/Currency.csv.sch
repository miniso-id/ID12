<?xml version="1.0" encoding="utf-8"?>
<table name="Currency">
  <column no="1" label="Code" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
  <column no="2" label="Name" type="12" typeName="varchar" precision="0" scale="0" displaySize="20" />
  <column no="3" label="FavRate" type="2" typeName="numeric" precision="20" scale="4" displaySize="0" />
  <column no="4" label="Cashier" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
  <column no="5" label="Change" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
  <column no="6" label="DLL" type="12" typeName="varchar" precision="0" scale="0" displaySize="50" />
  <column no="7" label="UseScope" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
  <column no="8" label="PayChkType" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
  <column no="9" label="ALWBCK" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
  <column no="10" label="AlwDlt" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
  <column no="11" label="PaidInFull" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
  <column no="12" label="LimitMbr" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
  <column no="13" label="PRIORITY" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
  <column no="14" label="ExpenseCardType" type="12" typeName="varchar" precision="0" scale="0" displaySize="100" />
  <column no="15" label="MIXLIMITAMT" type="2" typeName="numeric" precision="20" scale="4" displaySize="0" />
  <column no="16" label="MAXLIMITAMT" type="2" typeName="numeric" precision="20" scale="4" displaySize="0" />
  <column no="17" label="POPCASHBOX" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
</table>
