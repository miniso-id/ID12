<?xml version="1.0" encoding="utf-8"?>
<table name="CurrencyFull">
  <column no="1" label="Code" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="2" label="Name" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="3" label="FavRate" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
  <column no="4" label="Cashier" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="5" label="Change" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="6" label="DLL" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="50" />
  <column no="7" label="UseScope" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="8" label="PayChkType" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="9" label="ALWBCK" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="10" label="AlwDlt" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="11" label="PaidInFull" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="12" label="NonPrimeBus" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
</table>
