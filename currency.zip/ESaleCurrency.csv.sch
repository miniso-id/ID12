<?xml version="1.0" encoding="utf-8"?>
<table name="ESaleCurrency">
  <column no="1" label="Code" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
  <column no="2" label="Name" type="12" typeName="varchar" precision="0" scale="0" displaySize="20" />
</table>
