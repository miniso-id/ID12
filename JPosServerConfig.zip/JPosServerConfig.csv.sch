<?xml version="1.0" encoding="utf-8"?>
<table name="JPosServerConfig">
  <column no="1" label="CODE" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="2" label="NAME" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="30" />
  <column no="3" label="URL" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="255" />
  <column no="4" label="NOTE" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="255" />
  <column no="5" label="SERVERTYPE" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="32" />
</table>
