<?xml version="1.0" encoding="utf-8"?>
<table name="USAFREETAXSCOPE">
  <column no="1" label="EFFECTDATE" type="93" typeName="TIMESTAMP" precision="0" scale="0" displaySize="0" />
  <column no="2" label="FREETAX" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="3" label="REMARK" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="255" />
</table>
