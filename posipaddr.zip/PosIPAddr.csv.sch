<?xml version="1.0" encoding="utf-8"?>
<table name="PosIPAddr">
  <column no="1" label="STORENO" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="32" />
  <column no="2" label="POSNO" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="32" />
  <column no="3" label="POSTYPE" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="4" label="IPADDR" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="32" />
  <column no="5" label="PORT" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="6" label="SCALEID" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="32" />
</table>
