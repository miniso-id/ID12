<?xml version="1.0" encoding="utf-8"?>
<table name="GoodsTaxCls">
  <column no="1" label="GdGid" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="2" label="TaxCode" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="32" />
  <column no="3" label="Note" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="255" />
</table>
