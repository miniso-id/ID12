<?xml version="1.0" encoding="utf-8"?>
<table name="SaleAssAdver">
  <column no="1" label="SCREENADS" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="500" />
  <column no="2" label="PRINTADS" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="500" />
  <column no="3" label="SRCNUM" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="14" />
  <column no="4" label="SRCCLS" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="10" />
  <column no="5" label="BgnDate" type="93" typeName="TIMESTAMP" precision="0" scale="0" displaySize="0" />
  <column no="6" label="EndDate" type="93" typeName="TIMESTAMP" precision="0" scale="0" displaySize="0" />
</table>
