<?xml version="1.0" encoding="utf-8"?>
<table name="StockTolerence">
  <column no="1" label="GDGID" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="2" label="TYPE" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="3" label="profitMax" type="2" typeName="NUMERIC" precision="16" scale="4" displaySize="0" />
  <column no="4" label="lossMax" type="2" typeName="NUMERIC" precision="16" scale="4" displaySize="0" />
  <column no="5" label="LIMITMODE" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
</table>
