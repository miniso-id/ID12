<?xml version="1.0" encoding="utf-8"?>
<table name="GuaranteePrmGDInvPeriodDtl">
  <column no="1" label="UUID" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="38" />
  <column no="2" label="OWNERUUID" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="38" />
  <column no="3" label="BEGINTIME" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="10" />
  <column no="4" label="ENDTIME" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="10" />
  <column no="5" label="RTLPRC" type="2" typeName="NUMERIC" precision="24" scale="4" displaySize="0" />
  <column no="6" label="MBRPRC" type="2" typeName="NUMERIC" precision="24" scale="4" displaySize="0" />
</table>
