<?xml version="1.0" encoding="utf-8"?>
<table name="PhaseOutPromInv">
  <column no="1" label="UUID" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="38" />
  <column no="2" label="GDGID" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="3" label="QPC" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
  <column no="4" label="BEGINDATE" type="93" typeName="TIMESTAMP" precision="0" scale="0" displaySize="0" />
  <column no="5" label="ENDDATE" type="93" typeName="TIMESTAMP" precision="0" scale="0" displaySize="0" />
  <column no="6" label="RTLPRC" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
  <column no="7" label="MBRPRC" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
  <column no="8" label="QTY" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
  <column no="9" label="SRCNUM" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="38" />
  <column no="10" label="SRCCLS" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="38" />
  <column no="11" label="LSTUPDTIME" type="93" typeName="TIMESTAMP" precision="0" scale="0" displaySize="0" />
</table>
