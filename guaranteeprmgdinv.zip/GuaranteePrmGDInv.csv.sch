<?xml version="1.0" encoding="utf-8"?>
<table name="GuaranteePrmGDInv">
  <column no="1" label="SRCNUM" type="12" typeName="varchar" precision="0" scale="0" displaySize="14" />
  <column no="2" label="SRCCLS" type="12" typeName="varchar" precision="0" scale="0" displaySize="10" />
  <column no="3" label="GDGID" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
  <column no="4" label="BGNDATE" type="93" typeName="timestamp" precision="0" scale="0" displaySize="0" />
  <column no="5" label="ENDDATE" type="93" typeName="timestamp" precision="0" scale="0" displaySize="0" />
  <column no="6" label="QPC" type="2" typeName="numeric" precision="20" scale="4" displaySize="0" />
  <column no="7" label="RTLPRC" type="2" typeName="numeric" precision="20" scale="4" displaySize="0" />
  <column no="8" label="MBRPRC" type="2" typeName="numeric" precision="20" scale="4" displaySize="0" />
  <column no="9" label="LMTQTY" type="2" typeName="numeric" precision="20" scale="4" displaySize="0" />
  <column no="10" label="UUID" type="12" typeName="varchar" precision="0" scale="0" displaySize="38" />
  <column no="11" label="FLAG" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
  <column no="12" label="LSTUPDTIME" type="93" typeName="timestamp" precision="0" scale="0" displaySize="0" />
  <column no="13" label="BNUM" type="12" typeName="varchar" precision="0" scale="0" displaySize="38" />
  <column no="14" label="PRICETYPE" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
  <column no="15" label="PRMRATE" type="2" typeName="numeric" precision="24" scale="2" displaySize="0" />
</table>
