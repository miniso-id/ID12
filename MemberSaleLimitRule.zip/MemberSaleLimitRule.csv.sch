<?xml version="1.0" encoding="utf-8"?>
<table name="MemberSaleLimitRule">
  <column no="1" label="UUID" type="12" typeName="varchar" precision="0" scale="0" displaySize="64" />
  <column no="2" label="NUM" type="12" typeName="varchar" precision="0" scale="0" displaySize="14" />
  <column no="3" label="STARTDATE" type="93" typeName="timestamp" precision="0" scale="0" displaySize="0" />
  <column no="4" label="ENDDATE" type="93" typeName="timestamp" precision="0" scale="0" displaySize="0" />
  <column no="5" label="CHKDATE" type="93" typeName="timestamp" precision="0" scale="0" displaySize="0" />
  <column no="6" label="SALELIMIT" type="4" typeName="integer" precision="0" scale="0" displaySize="0" />
  <column no="7" label="LIMITQTY" type="2" typeName="numeric" precision="20" scale="4" displaySize="0" />
</table>
