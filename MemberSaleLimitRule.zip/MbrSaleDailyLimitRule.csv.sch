<?xml version="1.0" encoding="utf-8"?>
<table name="MbrSaleDailyLimitRule">
  <column no="1" label="num" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="14" />
  <column no="2" label="gdgid" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="3" label="qty" type="2" typeName="NUMERIC" precision="24" scale="4" displaySize="0" />
  <column no="4" label="limitdate" type="93" typeName="TIMESTAMP" precision="0" scale="0" displaySize="0" />
  <column no="5" label="memberlimit" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
</table>
