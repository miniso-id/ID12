<?xml version="1.0" encoding="utf-8"?>
<table name="MemberSaleLimitRuleGoods">
  <column no="1" label="UUID" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="64" />
  <column no="2" label="NUM" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="14" />
  <column no="3" label="LINE" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="4" label="GDGID" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="5" label="LIMITQTY" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
</table>
