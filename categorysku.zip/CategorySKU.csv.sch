<?xml version="1.0" encoding="utf-8"?>
<table name="CategorySKU">
  <column no="1" label="SKU" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="2" label="STOREGID" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="3" label="SORT" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="10" />
</table>
