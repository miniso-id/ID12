<?xml version="1.0" encoding="utf-8"?>
<table name="HANDINBANKACCOUNTINFO">
  <column no="1" label="STOREGID" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="2" label="CODE" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="32" />
  <column no="3" label="BANKNAME" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="128" />
  <column no="4" label="BANKACCOUNTNO" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="64" />
</table>
