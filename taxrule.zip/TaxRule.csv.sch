<?xml version="1.0" encoding="utf-8"?>
<table name="TaxRule">
  <column no="1" label="TRCode" type="12" typeName="varchar" precision="0" scale="0" displaySize="30" />
  <column no="2" label="TaxCode" type="12" typeName="varchar" precision="0" scale="0" displaySize="20" />
  <column no="3" label="TaxType" type="12" typeName="varchar" precision="0" scale="0" displaySize="50" />
  <column no="4" label="TaxRate" type="2" typeName="numeric" precision="20" scale="4" displaySize="0" />
  <column no="5" label="FixedTax" type="2" typeName="numeric" precision="20" scale="4" displaySize="0" />
  <column no="6" label="includeTax" type="2" typeName="numeric" precision="20" scale="4" displaySize="0" />
</table>
