<?xml version="1.0" encoding="utf-8"?>
<table name="TaxRule">
  <column no="1" label="TRCode" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="30" />
  <column no="2" label="TaxCode" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="3" label="TaxType" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="50" />
  <column no="4" label="TaxRate" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
  <column no="5" label="FixedTax" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
  <column no="6" label="includeTax" type="2" typeName="NUMERIC" precision="20" scale="4" displaySize="0" />
  <column no="7" label="threshold" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="40" />
  <column no="8" label="cap" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="9" label="taxRuleOptions" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="40" />
  <column no="10" label="effDate" type="93" typeName="TIMESTAMP" precision="0" scale="0" displaySize="0" />
  <column no="11" label="endDate" type="93" typeName="TIMESTAMP" precision="0" scale="0" displaySize="0" />
</table>
