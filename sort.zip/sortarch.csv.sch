<?xml version="1.0" encoding="utf-8"?>
<table name="sortarch">
  <column no="1" label="acode" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="13" />
  <column no="2" label="aname" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="40" />
  <column no="3" label="applyTo" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
</table>
