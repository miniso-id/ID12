<?xml version="1.0" encoding="utf-8"?>
<table name="sortname">
  <column no="1" label="acode" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="13" />
  <column no="2" label="scode" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="20" />
  <column no="3" label="sname" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="255" />
  <column no="4" label="lvl" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
  <column no="5" label="reqOrderDeadTime" type="12" typeName="VARCHAR" precision="0" scale="0" displaySize="10" />
  <column no="6" label="AlwInvoice" type="4" typeName="INTEGER" precision="0" scale="0" displaySize="0" />
</table>
